import type { ButtonHTMLAttributes } from "react";

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary";
};

export function Button({ variant = "primary", className, ...props }: ButtonProps) {
  return <button className={["ra-button", `ra-button-${variant}`, className].filter(Boolean).join(" ")} {...props} />;
}
