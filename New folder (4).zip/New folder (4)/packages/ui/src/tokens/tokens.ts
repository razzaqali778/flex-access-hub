export const tokens = {
  radius: {
    sm: "4px",
    md: "8px",
  },
  color: {
    ink: "#08152f",
    brand: "#2e63df",
    surface: "#ffffff",
  },
};
