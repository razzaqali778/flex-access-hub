export const REPORTING_PROJECTION_REFRESHED_EVENT = "reporting.projection-refreshed.v1";

export type ReportingProjectionRefreshedPayload = {
  projectionName: string;
  refreshedAt: string;
};
