import type { IntegrationEvent } from "./integration-event.contract";

export type OutcomeCreatedPayload = {
  outcomeId: string;
  title: string;
  owner: string;
};

export type OutcomeCreatedEvent = IntegrationEvent<OutcomeCreatedPayload>;

export const OUTCOME_CREATED_EVENT = "outcome.created.v1";
