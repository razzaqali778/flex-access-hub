export const RESOURCE_FORECAST_ALLOCATED_EVENT = "resource-forecast.allocated.v1";

export type ResourceForecastAllocatedPayload = {
  scenarioId: string;
  division: string;
  allocatedFte: number;
  allocatedBudgetEur: number;
};
