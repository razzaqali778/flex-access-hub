export const USER_ROLE_ASSIGNED_EVENT = "user.role-assigned.v1";

export type UserRoleAssignedPayload = {
  userId: string;
  role: string;
  assignedBy: string;
};
