export const PRIORITIZATION_PLAN_LOCKED_EVENT = "prioritization.plan-locked.v1";

export type PrioritizationPlanLockedPayload = {
  planId: string;
  division: string;
  lockedBy: string;
};
