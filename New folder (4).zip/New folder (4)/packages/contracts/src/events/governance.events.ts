export const AUDIT_ENTRY_RECORDED_EVENT = "audit.entry-recorded.v1";

export type AuditEntryRecordedPayload = {
  auditEntryId: string;
  actorId: string;
  action: string;
  resourceType: string;
  resourceId: string;
};
