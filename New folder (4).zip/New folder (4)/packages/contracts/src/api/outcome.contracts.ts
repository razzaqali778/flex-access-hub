export type OutcomeStatus = "Active" | "Planned";

export type OutcomeDto = {
  id: string;
  title: string;
  functionName: string;
  platform: string;
  owner: string;
  status: OutcomeStatus;
  roi: number;
  demandFte: number;
  fundingEur: number;
  governanceTag?: string;
};

export type CreateOutcomeRequest = {
  title: string;
  functionName: string;
  platform: string;
  owner: string;
  roi: number;
  demandFte: number;
  fundingEur: number;
  governanceTag?: string;
};
