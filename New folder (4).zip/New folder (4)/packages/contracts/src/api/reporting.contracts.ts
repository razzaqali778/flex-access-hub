export type ReportingMetricDto = {
  key: string;
  label: string;
  value: number;
  unit?: string;
};
