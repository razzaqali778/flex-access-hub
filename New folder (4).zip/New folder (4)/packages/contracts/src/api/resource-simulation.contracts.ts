export type ResourceScenarioDto = {
  id: string;
  division: string;
  fteCap: number;
  budgetCapEur: number;
  allocatedFte: number;
  allocatedBudgetEur: number;
};
