export type UserRoleDto = "PortfolioLead" | "DivisionLead" | "Viewer" | "Admin";

export type UserDto = {
  id: string;
  displayName: string;
  email: string;
  role: UserRoleDto;
  division?: string;
};
