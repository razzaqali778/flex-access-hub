export type PrioritizationPlanStatus = "Draft" | "Locked" | "Submitted";

export type PrioritizationPlanDto = {
  id: string;
  division: string;
  status: PrioritizationPlanStatus;
  rankedOutcomeIds: string[];
};
