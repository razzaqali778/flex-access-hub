export type AuditEntryDto = {
  id: string;
  actorId: string;
  action: string;
  resourceType: string;
  resourceId: string;
  occurredAt: string;
};

export type GovernanceTagDto = {
  id: string;
  label: string;
  category: "Compliance" | "Funding" | "Strategic" | "Risk";
};
