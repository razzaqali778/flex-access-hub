export * from "./prisma.service";
