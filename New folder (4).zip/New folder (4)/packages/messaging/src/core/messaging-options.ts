export type MessagingOptions = {
  url: string;
  exchange: string;
};

export const MESSAGING_OPTIONS = Symbol("MESSAGING_OPTIONS");

export function getMessagingOptions(): MessagingOptions {
  return {
    url: process.env.RABBITMQ_URL ?? "amqp://resource:resource@localhost:5672",
    exchange: process.env.RABBITMQ_EXCHANGE ?? "resource.allocation.events",
  };
}
