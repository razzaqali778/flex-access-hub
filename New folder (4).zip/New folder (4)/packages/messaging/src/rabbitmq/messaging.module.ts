import { DynamicModule, Module } from "@nestjs/common";
import { EventPublisher } from "../contracts/message-publisher";
import { getMessagingOptions, MESSAGING_OPTIONS, type MessagingOptions } from "../core/messaging-options";
import { RabbitMqEventPublisher } from "./rabbitmq-event.publisher";

@Module({})
export class MessagingModule {
  static forRoot(options: Partial<MessagingOptions> = {}): DynamicModule {
    return {
      module: MessagingModule,
      providers: [
        {
          provide: MESSAGING_OPTIONS,
          useValue: {
            ...getMessagingOptions(),
            ...options,
          },
        },
        {
          provide: EventPublisher,
          useClass: RabbitMqEventPublisher,
        },
      ],
      exports: [EventPublisher],
    };
  }
}
