import { Inject, Injectable, OnModuleDestroy } from "@nestjs/common";
import type { IntegrationEvent } from "@resource-allocation/contracts";
import amqp, { type Channel, type ChannelModel } from "amqplib";
import { MESSAGING_OPTIONS, type MessagingOptions } from "../core/messaging-options";
import { EventPublisher } from "../contracts/message-publisher";

@Injectable()
export class RabbitMqEventPublisher extends EventPublisher implements OnModuleDestroy {
  private connection?: ChannelModel;
  private channel?: Channel;

  constructor(@Inject(MESSAGING_OPTIONS) private readonly options: MessagingOptions) {
    super();
  }

  async publish<TPayload>(routingKey: string, event: IntegrationEvent<TPayload>) {
    const channel = await this.getChannel();
    const body = Buffer.from(JSON.stringify(event));

    const published = channel.publish(this.options.exchange, routingKey, body, {
      contentType: "application/json",
      deliveryMode: 2,
      messageId: "id" in event && typeof event.id === "string" ? event.id : undefined,
      timestamp: Date.now(),
    });

    if (!published) {
      await new Promise((resolve) => channel.once("drain", resolve));
    }
  }

  async onModuleDestroy() {
    await this.channel?.close();
    await this.connection?.close();
  }

  private async getChannel() {
    if (this.channel) {
      return this.channel;
    }

    this.connection = await amqp.connect(this.options.url);
    const channel = await this.connection.createChannel();
    await channel.assertExchange(this.options.exchange, "topic", {
      durable: true,
    });
    this.channel = channel;

    return channel;
  }
}
