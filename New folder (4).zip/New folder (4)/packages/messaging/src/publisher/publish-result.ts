export type PublishResult = {
  routingKey: string;
  publishedAt: string;
};
