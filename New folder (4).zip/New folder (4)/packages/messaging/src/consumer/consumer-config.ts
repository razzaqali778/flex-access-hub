export type ConsumerConfig = {
  queue: string;
  routingKeys: string[];
  deadLetterQueue?: string;
  prefetch?: number;
};
