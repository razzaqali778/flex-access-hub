import type { IntegrationEvent } from "@resource-allocation/contracts";
import { EventPublisher } from "../contracts/message-publisher";

export class FakeEventPublisher extends EventPublisher {
  readonly published: Array<{ routingKey: string; event: IntegrationEvent<unknown> }> = [];

  async publish<TPayload>(routingKey: string, event: IntegrationEvent<TPayload>) {
    this.published.push({ routingKey, event: event as IntegrationEvent<unknown> });
  }
}
