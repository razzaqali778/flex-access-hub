import type { IntegrationEvent } from "@resource-allocation/contracts";

export abstract class EventPublisher {
  abstract publish<TPayload>(
    routingKey: string,
    event: IntegrationEvent<TPayload>,
  ): Promise<void>;
}
