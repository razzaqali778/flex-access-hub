export type DomainEvent<TPayload = unknown> = {
  id: string;
  name: string;
  occurredAt: Date;
  payload: TPayload;
};
