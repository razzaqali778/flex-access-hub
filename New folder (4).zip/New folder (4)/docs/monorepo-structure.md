# Monorepo Structure

```text
apps/
  api/
    src/modules/
      outcomes/
      prioritization/
      resource-simulation/
      governance/
      users/
      reporting/
  web/
    src/modules/
      outcomes/
      prioritization/
      resource-simulation/
      governance/
      users/
      reporting/

packages/
  config/
  contracts/
  database/
  messaging/
  shared-kernel/
  ui/

docs/
  hld/
  lld/
```

## Dependency Direction

```text
apps/web -> packages/ui, packages/contracts, packages/shared-kernel
apps/api -> packages/contracts, packages/database, packages/messaging, packages/shared-kernel
packages/messaging -> packages/contracts, packages/shared-kernel
packages/database -> packages/shared-kernel
```

## Naming

- packages use `@resource-allocation/*`
- backend modules use domain names
- event names use `domain.action.v1`
- DTO files use `*.dto.ts`
- Redux slices use `*.slice.ts`
