# HLD: System Overview

## Purpose

This HLD defines the system-level architecture for the resource allocation platform.

## Architecture Style

The platform is a modulith:

- one frontend deployable
- one backend deployable
- one PostgreSQL database
- one RabbitMQ broker
- multiple internal business modules with strict boundaries

This keeps delivery simple while preserving future service extraction options.

## Major Components

```text
React Web
  - routing
  - Redux application state
  - feature modules
  - API clients

NestJS API
  - REST endpoints
  - application use cases
  - domain modules
  - persistence adapters
  - event publication

PostgreSQL
  - transactional source of truth
  - module-owned tables

RabbitMQ
  - asynchronous communication
  - retries and DLQ
  - future external event consumers
```

## Non-Functional Requirements

- clear module ownership
- typed contracts across frontend and backend
- auditable business actions
- reproducible local environment
- CI validation for build, test, typecheck, and migrations
- event publishing through a reusable broker library

## Runtime Flow

```text
Browser route
  -> React feature module
  -> API client
  -> NestJS controller
  -> application handler
  -> domain entity
  -> repository
  -> PostgreSQL
  -> domain event mapper
  -> RabbitMQ publisher
```
