# HLD: Module Landscape

## Frontend Modules

- `outcomes`: portfolio list and outcome details
- `prioritization`: division prioritization screen and filters
- `resource-simulation`: staffing forecast and capacity side panel
- `governance`: governance tags and audit log status
- `users`: signed-in user and role context
- `reporting`: monitoring, steering, and history views

## Backend Modules

- `outcomes`: outcome aggregate, status, priority, tags, funding, FTE demand
- `prioritization`: ranking rules, lock/submit state, division plan workflow
- `resource-simulation`: capacity model, forecast allocation, staffing checks
- `governance`: audit entries, governance log integration, compliance tags
- `users`: users, roles, permissions, division membership
- `reporting`: read models and dashboard summaries

## Module Communication

Use synchronous calls for request/response workflows:

- fetch outcomes
- update rank
- lock prioritization plan
- calculate visible resource summary

Use events for side effects:

- audit entry creation
- notification requests
- reporting projections
- plan locked events
- outcome updated events

## Implementation Status

The repository currently scaffolds all listed modules. `outcomes` is the first implemented vertical slice; the remaining modules have folders, module registration, starter controllers, contracts, and domain placeholder types.

## Event Candidates

- `outcome.created.v1`
- `outcome.updated.v1`
- `outcome.ranked.v1`
- `prioritization.plan-locked.v1`
- `resource-forecast.allocated.v1`
- `audit.entry-recorded.v1`
