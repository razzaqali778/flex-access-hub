# HLD Index

The HLD content is organized under `docs/hld`.

- [System Overview](./hld/overview.md)
- [Module Landscape](./hld/modules.md)
