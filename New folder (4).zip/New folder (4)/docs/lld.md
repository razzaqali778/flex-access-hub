# LLD Index

The LLD content is organized under `docs/lld`.

- [Frontend](./lld/frontend.md)
- [Backend](./lld/backend.md)
- [Database](./lld/database.md)
- [Messaging](./lld/messaging.md)
