# Architecture Overview

## Decision

Use a modulith-first architecture.

The system has one React frontend, one NestJS backend, one PostgreSQL database, and RabbitMQ for asynchronous communication. Backend modules are strictly separated internally so modules can be extracted later if there is a real operational reason.

## System View

```text
User
  -> React Web App
  -> NestJS API Modulith
  -> PostgreSQL

NestJS API Modulith
  -> packages/messaging
  -> RabbitMQ
```

## Primary Deployables

- `apps/web`: browser application
- `apps/api`: API application
- `postgres`: transactional database
- `rabbitmq`: event broker

## Shared Packages

- `packages/contracts`: API and event contracts
- `packages/database`: Prisma schema and database client
- `packages/messaging`: RabbitMQ abstraction
- `packages/shared-kernel`: domain primitives and common types
- `packages/ui`: reusable React components

## Boundary Rule

Business modules own their domain logic, application use cases, persistence access, and API surface. Shared packages provide infrastructure and contracts only.

## Product Module Map

- `outcomes`: outcomes portfolio and lifecycle
- `prioritization`: ranking, filters, lock/submit workflow
- `resource-simulation`: staffing forecast, FTE, funding, capacity
- `governance`: tags, audit, fixed items, logs
- `users`: signed-in users, roles, access
- `reporting`: monitoring, steering, history

## Event Strategy

Use domain events inside the backend module and integration events at the RabbitMQ boundary.

Example:

```text
OutcomeRankedDomainEvent
  -> outcome.ranked.v1
```

RabbitMQ code must stay in `packages/messaging`. Feature modules publish through an abstraction.
