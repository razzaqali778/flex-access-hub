# Implementation Plan

## Phase 1: Foundation

- npm workspace
- Turbo tasks
- shared TypeScript config
- Docker Compose for PostgreSQL and RabbitMQ
- GitHub Actions CI

## Phase 2: Frontend Boilerplate

- Vite React app
- Redux store
- app shell
- `/outcomes` and `/prioritize` routes
- feature module folders
- shared UI package

## Phase 3: Backend Boilerplate

- NestJS app
- health endpoint
- outcomes module
- layered module structure
- Prisma repository interface and adapter
- placeholder modules for prioritization, resource simulation, governance, users, and reporting

## Phase 4: Messaging Library

- RabbitMQ connection config
- publisher interface
- RabbitMQ publisher
- fake publisher for tests
- event contract conventions

## Phase 5: Database

- Prisma schema
- initial `Outcome` model
- migration validation workflow

## Phase 6: First Product Slice

Build `outcomes` end to end:

- frontend list
- backend API
- PostgreSQL persistence
- `outcome.created.v1` integration event

## Phase 7: Prioritization Slice

Build `/prioritize`:

- filter chips
- ranked outcomes
- resource simulation side panel
- lock division workflow
- audit/governance event emission

## Scaffolded Module Inventory

Frontend:

- `outcomes`
- `prioritization`
- `resource-simulation`
- `governance`
- `users`
- `reporting`

Backend:

- `outcomes`
- `prioritization`
- `resource-simulation`
- `governance`
- `users`
- `reporting`
