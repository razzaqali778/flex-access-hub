# LLD: Messaging

## Decision

RabbitMQ integration lives in `packages/messaging`.

Feature modules must not create RabbitMQ connections directly.

## Package Responsibilities

- connection lifecycle
- exchange assertion
- publisher abstraction
- consumer abstraction
- JSON serialization
- retry metadata
- dead-letter queue naming
- correlation ID propagation
- fake publisher for tests

## Event Contract Shape

```ts
type IntegrationEvent<TPayload> = {
  id: string;
  name: string;
  version: number;
  occurredAt: string;
  correlationId?: string;
  payload: TPayload;
};
```

## Routing Key Convention

```text
domain.action.v1
```

Examples:

- `outcome.created.v1`
- `outcome.ranked.v1`
- `prioritization.plan-locked.v1`
