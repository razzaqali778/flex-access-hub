# LLD: Frontend

## Technology

- React
- Vite
- TypeScript
- Redux Toolkit
- React Router

## Structure

```text
apps/web/src/
  app/
    layouts/
    providers/
    router/
    store/
  modules/
    outcomes/
    prioritization/
  shared/
    api/
    hooks/
    lib/
    state/
```

## Redux Rules

- Use Redux Toolkit slices for durable UI state.
- Keep server data fetching behind feature API modules.
- Keep state local if it only affects one component.
- Do not put backend DTOs directly into complex UI state when a view model is clearer.

## Feature Module Template

```text
modules/prioritization/
  api/
  components/
  pages/
  state/
  types/
```

## Initial Screens

- `/outcomes`: outcomes portfolio
- `/prioritize`: division prioritization with filters, ranked list, and resource simulation summary
