# LLD: Backend

## Technology

- NestJS
- TypeScript
- Prisma
- PostgreSQL
- RabbitMQ through `packages/messaging`

## Structure

```text
apps/api/src/
  app.module.ts
  main.ts
  health/
  modules/
    outcomes/
      application/
      domain/
      infrastructure/
      presentation/
```

## Layer Rules

### Domain

- entities
- value objects
- domain events
- repository interfaces

No NestJS, Prisma, or RabbitMQ imports.

### Application

- commands
- queries
- handlers
- use case orchestration

Depends on domain abstractions.

### Infrastructure

- Prisma repositories
- event publishers
- external integration adapters

Implements interfaces.

### Presentation

- controllers
- request DTOs
- response DTOs

Calls application handlers only.

## Initial Vertical Slice

`POST /api/outcomes`

```text
OutcomesController
  -> CreateOutcomeHandler
  -> Outcome entity
  -> OutcomeRepository
  -> Prisma
  -> OutcomeEventsPublisher
  -> packages/messaging
```
