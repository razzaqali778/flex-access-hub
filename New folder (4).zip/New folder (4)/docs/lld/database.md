# LLD: Database

## Decision

Use PostgreSQL with Prisma.

## Ownership

One physical database is shared by the backend modulith, but tables are owned by modules.

Initial ownership:

- `outcomes`: `outcomes`
- `users`: future user and role tables
- `governance`: future audit tables
- `reporting`: future projection tables

## Migration Rules

- migrations are generated through `packages/database`
- schema changes must be reviewed with module ownership in mind
- CI validates Prisma schema before merge

## Local Database

```bash
docker compose up -d postgres
npm run db:generate
npm run db:migrate
```
