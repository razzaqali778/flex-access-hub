export type ReportingMetric = {
  key: string;
  label: string;
  value: number;
  unit?: string;
};
