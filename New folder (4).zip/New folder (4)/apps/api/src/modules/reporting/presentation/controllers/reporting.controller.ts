import { Controller, Get } from "@nestjs/common";

@Controller("reporting")
export class ReportingController {
  @Get("summary")
  getSummary() {
    return {
      module: "reporting",
      responsibilities: [
        "monitoring dashboards",
        "history views",
        "read-model projections",
      ],
    };
  }
}
