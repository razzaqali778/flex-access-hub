import { Module } from "@nestjs/common";
import { ReportingController } from "./presentation/controllers/reporting.controller";

@Module({
  controllers: [ReportingController],
})
export class ReportingModule {}
