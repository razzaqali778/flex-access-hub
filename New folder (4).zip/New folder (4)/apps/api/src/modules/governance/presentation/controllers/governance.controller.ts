import { Controller, Get } from "@nestjs/common";

@Controller("governance")
export class GovernanceController {
  @Get("summary")
  getSummary() {
    return {
      module: "governance",
      responsibilities: [
        "governance tags",
        "audit trail",
        "compliance decision traceability",
      ],
    };
  }
}
