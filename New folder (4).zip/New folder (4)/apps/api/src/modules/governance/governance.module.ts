import { Module } from "@nestjs/common";
import { GovernanceController } from "./presentation/controllers/governance.controller";

@Module({
  controllers: [GovernanceController],
})
export class GovernanceModule {}
