import { Controller, Get } from "@nestjs/common";

@Controller("users")
export class UsersController {
  @Get("summary")
  getSummary() {
    return {
      module: "users",
      responsibilities: [
        "user profile",
        "role assignment",
        "division access",
      ],
    };
  }
}
