export type UserRole = "PortfolioLead" | "DivisionLead" | "Viewer" | "Admin";

export type User = {
  id: string;
  displayName: string;
  email: string;
  role: UserRole;
  division?: string;
};
