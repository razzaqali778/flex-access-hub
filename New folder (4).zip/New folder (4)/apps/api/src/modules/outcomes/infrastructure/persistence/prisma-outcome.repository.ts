import { Injectable } from "@nestjs/common";
import { prisma } from "@resource-allocation/database";
import { Outcome } from "../../domain/entities/outcome.entity";
import type { OutcomeRepository } from "../../domain/repositories/outcome.repository";

@Injectable()
export class PrismaOutcomeRepository implements OutcomeRepository {
  async save(outcome: Outcome): Promise<Outcome> {
    const data = outcome.toPrimitives();
    const saved = await prisma.outcome.create({
      data,
    });

    return Outcome.rehydrate({
      id: saved.id,
      title: saved.title,
      functionName: saved.functionName,
      platform: saved.platform,
      owner: saved.owner,
      status: saved.status as "Active" | "Planned",
      roi: saved.roi,
      demandFte: saved.demandFte,
      fundingEur: saved.fundingEur,
      governanceTag: saved.governanceTag ?? undefined,
    });
  }

  async findAll(): Promise<Outcome[]> {
    const rows = await prisma.outcome.findMany({
      orderBy: { createdAt: "desc" },
    });

    return rows.map((row) =>
      Outcome.rehydrate({
        id: row.id,
        title: row.title,
        functionName: row.functionName,
        platform: row.platform,
        owner: row.owner,
        status: row.status as "Active" | "Planned",
        roi: row.roi,
        demandFte: row.demandFte,
        fundingEur: row.fundingEur,
        governanceTag: row.governanceTag ?? undefined,
      }),
    );
  }
}
