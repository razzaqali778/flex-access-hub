import { Injectable } from "@nestjs/common";
import { randomUUID } from "node:crypto";
import { OUTCOME_CREATED_EVENT, type OutcomeCreatedEvent } from "@resource-allocation/contracts";
import { EventPublisher } from "@resource-allocation/messaging";
import type { OutcomeCreatedDomainEvent } from "../../domain/events/outcome-created.domain-event";

@Injectable()
export class OutcomeEventsPublisher {
  constructor(private readonly eventPublisher: EventPublisher) {}

  async publish(events: OutcomeCreatedDomainEvent[]) {
    for (const event of events) {
      const integrationEvent: OutcomeCreatedEvent = {
        id: randomUUID(),
        name: OUTCOME_CREATED_EVENT,
        version: 1,
        occurredAt: event.occurredAt.toISOString(),
        payload: event.payload,
      };

      await this.eventPublisher.publish(OUTCOME_CREATED_EVENT, integrationEvent);
    }
  }
}
