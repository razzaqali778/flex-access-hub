export type CreateOutcomeCommand = {
  title: string;
  functionName: string;
  platform: string;
  owner: string;
  roi: number;
  demandFte: number;
  fundingEur: number;
  governanceTag?: string;
};
