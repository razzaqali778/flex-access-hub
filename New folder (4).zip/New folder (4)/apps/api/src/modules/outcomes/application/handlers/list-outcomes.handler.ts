import { Inject, Injectable } from "@nestjs/common";
import type { OutcomeResponseDto } from "../dto/outcome.dto";
import { OUTCOME_REPOSITORY, type OutcomeRepository } from "../../domain/repositories/outcome.repository";

@Injectable()
export class ListOutcomesHandler {
  constructor(@Inject(OUTCOME_REPOSITORY) private readonly outcomeRepository: OutcomeRepository) {}

  async execute(): Promise<OutcomeResponseDto[]> {
    const outcomes = await this.outcomeRepository.findAll();
    return outcomes.map((outcome) => outcome.toPrimitives());
  }
}
