import { Inject, Injectable } from "@nestjs/common";
import type { OutcomeResponseDto } from "../dto/outcome.dto";
import type { CreateOutcomeCommand } from "../commands/create-outcome.command";
import { Outcome } from "../../domain/entities/outcome.entity";
import { OUTCOME_REPOSITORY, type OutcomeRepository } from "../../domain/repositories/outcome.repository";
import { OutcomeEventsPublisher } from "../../infrastructure/events/outcome-events.publisher";

@Injectable()
export class CreateOutcomeHandler {
  constructor(
    @Inject(OUTCOME_REPOSITORY) private readonly outcomeRepository: OutcomeRepository,
    private readonly outcomeEventsPublisher: OutcomeEventsPublisher,
  ) {}

  async execute(command: CreateOutcomeCommand): Promise<OutcomeResponseDto> {
    const outcome = Outcome.create(command);
    const saved = await this.outcomeRepository.save(outcome);

    await this.outcomeEventsPublisher.publish(saved.pullDomainEvents());

    return saved.toPrimitives();
  }
}
