export type OutcomeResponseDto = {
  id: string;
  title: string;
  functionName: string;
  platform: string;
  owner: string;
  status: "Active" | "Planned";
  roi: number;
  demandFte: number;
  fundingEur: number;
  governanceTag?: string;
};
