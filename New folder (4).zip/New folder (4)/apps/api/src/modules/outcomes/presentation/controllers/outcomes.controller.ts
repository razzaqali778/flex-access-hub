import { Body, Controller, Get, Post } from "@nestjs/common";
import { CreateOutcomeHandler } from "../../application/handlers/create-outcome.handler";
import { ListOutcomesHandler } from "../../application/handlers/list-outcomes.handler";
import { CreateOutcomeRequestDto } from "../request/create-outcome.request";

@Controller("outcomes")
export class OutcomesController {
  constructor(
    private readonly createOutcomeHandler: CreateOutcomeHandler,
    private readonly listOutcomesHandler: ListOutcomesHandler,
  ) {}

  @Get()
  list() {
    return this.listOutcomesHandler.execute();
  }

  @Post()
  create(@Body() request: CreateOutcomeRequestDto) {
    return this.createOutcomeHandler.execute(request);
  }
}
