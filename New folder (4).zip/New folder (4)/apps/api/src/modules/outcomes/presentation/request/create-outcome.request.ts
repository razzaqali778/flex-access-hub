import { IsInt, IsNumber, IsOptional, IsPositive, IsString, Min } from "class-validator";

export class CreateOutcomeRequestDto {
  @IsString()
  title!: string;

  @IsString()
  functionName!: string;

  @IsString()
  platform!: string;

  @IsString()
  owner!: string;

  @IsNumber()
  @IsPositive()
  roi!: number;

  @IsInt()
  @Min(0)
  demandFte!: number;

  @IsInt()
  @Min(0)
  fundingEur!: number;

  @IsOptional()
  @IsString()
  governanceTag?: string;
}
