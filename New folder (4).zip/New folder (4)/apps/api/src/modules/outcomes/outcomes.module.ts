import { Module } from "@nestjs/common";
import { MessagingModule } from "@resource-allocation/messaging";
import { CreateOutcomeHandler } from "./application/handlers/create-outcome.handler";
import { ListOutcomesHandler } from "./application/handlers/list-outcomes.handler";
import { OUTCOME_REPOSITORY } from "./domain/repositories/outcome.repository";
import { OutcomeEventsPublisher } from "./infrastructure/events/outcome-events.publisher";
import { PrismaOutcomeRepository } from "./infrastructure/persistence/prisma-outcome.repository";
import { OutcomesController } from "./presentation/controllers/outcomes.controller";

@Module({
  imports: [MessagingModule.forRoot()],
  controllers: [OutcomesController],
  providers: [
    CreateOutcomeHandler,
    ListOutcomesHandler,
    OutcomeEventsPublisher,
    {
      provide: OUTCOME_REPOSITORY,
      useClass: PrismaOutcomeRepository,
    },
  ],
})
export class OutcomesModule {}
