import type { Outcome } from "../entities/outcome.entity";

export const OUTCOME_REPOSITORY = Symbol("OUTCOME_REPOSITORY");

export interface OutcomeRepository {
  save(outcome: Outcome): Promise<Outcome>;
  findAll(): Promise<Outcome[]>;
}
