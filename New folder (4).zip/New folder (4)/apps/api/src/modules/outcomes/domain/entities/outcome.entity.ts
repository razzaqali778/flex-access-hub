import { randomUUID } from "node:crypto";
import { createOutcomeCreatedDomainEvent } from "../events/outcome-created.domain-event";

export type OutcomeProps = {
  id: string;
  title: string;
  functionName: string;
  platform: string;
  owner: string;
  status: "Active" | "Planned";
  roi: number;
  demandFte: number;
  fundingEur: number;
  governanceTag?: string;
};

export class Outcome {
  private readonly domainEvents: ReturnType<typeof createOutcomeCreatedDomainEvent>[] = [];

  private constructor(private readonly props: OutcomeProps) {}

  static create(props: Omit<OutcomeProps, "id" | "status"> & { id?: string; status?: "Active" | "Planned" }) {
    const outcome = new Outcome({
      title: props.title,
      functionName: props.functionName,
      platform: props.platform,
      owner: props.owner,
      roi: props.roi,
      demandFte: props.demandFte,
      fundingEur: props.fundingEur,
      governanceTag: props.governanceTag,
      id: props.id ?? randomUUID(),
      status: props.status ?? "Active",
    });

    outcome.domainEvents.push(
      createOutcomeCreatedDomainEvent({
        outcomeId: outcome.id,
        title: outcome.title,
        owner: outcome.owner,
      }),
    );

    return outcome;
  }

  static rehydrate(props: OutcomeProps) {
    return new Outcome(props);
  }

  get id() {
    return this.props.id;
  }

  get title() {
    return this.props.title;
  }

  get owner() {
    return this.props.owner;
  }

  toPrimitives(): OutcomeProps {
    return { ...this.props };
  }

  pullDomainEvents() {
    return this.domainEvents.splice(0, this.domainEvents.length);
  }
}
