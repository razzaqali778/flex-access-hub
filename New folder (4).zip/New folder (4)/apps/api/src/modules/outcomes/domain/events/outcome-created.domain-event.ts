import { randomUUID } from "node:crypto";
import type { DomainEvent } from "@resource-allocation/shared-kernel";

export type OutcomeCreatedDomainPayload = {
  outcomeId: string;
  title: string;
  owner: string;
};

export type OutcomeCreatedDomainEvent = DomainEvent<OutcomeCreatedDomainPayload>;

export function createOutcomeCreatedDomainEvent(
  payload: OutcomeCreatedDomainPayload,
): OutcomeCreatedDomainEvent {
  return {
    id: randomUUID(),
    name: "OutcomeCreatedDomainEvent",
    occurredAt: new Date(),
    payload,
  };
}
