import { Module } from "@nestjs/common";
import { PrioritizationController } from "./presentation/controllers/prioritization.controller";

@Module({
  controllers: [PrioritizationController],
})
export class PrioritizationModule {}
