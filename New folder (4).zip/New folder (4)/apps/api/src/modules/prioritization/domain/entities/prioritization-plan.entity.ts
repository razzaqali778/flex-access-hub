export type PrioritizationPlanStatus = "Draft" | "Locked" | "Submitted";

export type PrioritizationPlan = {
  id: string;
  division: string;
  status: PrioritizationPlanStatus;
  rankedOutcomeIds: string[];
};
