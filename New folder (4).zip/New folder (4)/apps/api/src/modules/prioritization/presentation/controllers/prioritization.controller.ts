import { Controller, Get } from "@nestjs/common";

@Controller("prioritization")
export class PrioritizationController {
  @Get("summary")
  getSummary() {
    return {
      module: "prioritization",
      responsibilities: [
        "ranking outcomes",
        "locking division plans",
        "submitting prioritization decisions",
      ],
    };
  }
}
