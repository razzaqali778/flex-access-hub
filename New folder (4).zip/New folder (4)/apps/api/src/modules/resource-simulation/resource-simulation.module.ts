import { Module } from "@nestjs/common";
import { ResourceSimulationController } from "./presentation/controllers/resource-simulation.controller";

@Module({
  controllers: [ResourceSimulationController],
})
export class ResourceSimulationModule {}
