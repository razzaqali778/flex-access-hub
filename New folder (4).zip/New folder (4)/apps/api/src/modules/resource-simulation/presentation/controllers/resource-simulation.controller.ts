import { Controller, Get } from "@nestjs/common";

@Controller("resource-simulation")
export class ResourceSimulationController {
  @Get("summary")
  getSummary() {
    return {
      module: "resource-simulation",
      responsibilities: [
        "capacity modeling",
        "funding forecast",
        "FTE demand simulation",
      ],
    };
  }
}
