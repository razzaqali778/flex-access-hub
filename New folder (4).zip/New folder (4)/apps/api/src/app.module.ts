import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { HealthModule } from "./health/health.module";
import { GovernanceModule } from "./modules/governance/governance.module";
import { OutcomesModule } from "./modules/outcomes/outcomes.module";
import { PrioritizationModule } from "./modules/prioritization/prioritization.module";
import { ReportingModule } from "./modules/reporting/reporting.module";
import { ResourceSimulationModule } from "./modules/resource-simulation/resource-simulation.module";
import { UsersModule } from "./modules/users/users.module";

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    HealthModule,
    OutcomesModule,
    PrioritizationModule,
    ResourceSimulationModule,
    GovernanceModule,
    UsersModule,
    ReportingModule,
  ],
})
export class AppModule {}
