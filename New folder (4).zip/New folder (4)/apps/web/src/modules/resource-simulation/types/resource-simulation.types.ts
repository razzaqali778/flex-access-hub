export type ResourceScenarioSummary = {
  id: string;
  division: string;
  fteCap: number;
  budgetCapEur: number;
  allocatedFte: number;
  allocatedBudgetEur: number;
};
