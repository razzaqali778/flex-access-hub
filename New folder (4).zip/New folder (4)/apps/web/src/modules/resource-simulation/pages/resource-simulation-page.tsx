export function ResourceSimulationPage() {
  return (
    <section className="page">
      <header className="page-header">
        <div>
          <h1>Resource Simulation</h1>
          <p>Capacity, FTE demand, funding caps, and staffing forecast scenarios.</p>
        </div>
      </header>
      <div className="empty-panel">
        This module will own forecast scenarios, capacity calculations, and allocated staffing summaries.
      </div>
    </section>
  );
}
