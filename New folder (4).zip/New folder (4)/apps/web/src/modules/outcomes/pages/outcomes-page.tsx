export function OutcomesPage() {
  return (
    <section className="page">
      <header className="page-header">
        <div>
          <h1>Outcomes</h1>
          <p>Portfolio outcomes that feed prioritization and staffing forecasts.</p>
        </div>
      </header>
      <div className="empty-panel">
        Outcome portfolio list will be implemented as the first product slice.
      </div>
    </section>
  );
}
