export function UsersPage() {
  return (
    <section className="page">
      <header className="page-header">
        <div>
          <h1>Users & Roles</h1>
          <p>User profiles, role assignment, division membership, and permission context.</p>
        </div>
      </header>
      <div className="empty-panel">
        This module will own user access, portfolio role mapping, and signed-in user context.
      </div>
    </section>
  );
}
