export type UserRole = "PortfolioLead" | "DivisionLead" | "Viewer" | "Admin";

export type UserSummary = {
  id: string;
  displayName: string;
  email: string;
  role: UserRole;
  division?: string;
};
