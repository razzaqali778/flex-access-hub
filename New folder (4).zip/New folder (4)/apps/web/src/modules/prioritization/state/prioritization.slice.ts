import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type { PrioritizationFilters } from "../types/prioritization.types";

const initialState: PrioritizationFilters = {
  division: "Consumer Health",
  level: "Execution",
  functionName: "All functions",
  platform: "All platforms",
  status: "All statuses",
  governance: "All tags",
};

const prioritizationSlice = createSlice({
  name: "prioritization",
  initialState,
  reducers: {
    filterChanged: (
      state,
      action: PayloadAction<{ key: keyof PrioritizationFilters; value: string }>,
    ) => {
      state[action.payload.key] = action.payload.value;
    },
  },
});

export const { filterChanged } = prioritizationSlice.actions;
export const prioritizationReducer = prioritizationSlice.reducer;
