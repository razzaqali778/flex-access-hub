import { BarChart3, WalletCards } from "lucide-react";

export function ResourceSimulation() {
  return (
    <aside className="simulation-panel">
      <header>
        <span>Resource Simulation</span>
        <strong>Consumer Health · Staffing Forecast</strong>
      </header>
      <section>
        <h3>
          <BarChart3 size={17} /> Division Capacity
        </h3>
        <div className="capacity-grid">
          <div>
            <span>FTE Cap</span>
            <strong>25</strong>
          </div>
          <div>
            <span>Budget Cap</span>
            <strong>€2.80M</strong>
          </div>
        </div>
      </section>
      <section>
        <h3>Total Demand</h3>
        <div className="demand-card">
          <span>All outcomes</span>
          <strong>31 FTE</strong>
          <strong>€1452k</strong>
        </div>
      </section>
      <section>
        <h3>
          <WalletCards size={17} /> Allocated Forecast
        </h3>
        <div className="progress-card">
          <div className="progress-label">
            <span>Funding</span>
            <strong>€2,177,000 left</strong>
          </div>
          <div className="progress-track">
            <span style={{ width: "22%" }} />
          </div>
          <div className="progress-label muted">
            <span>€623k allocated</span>
            <span>€2800k cap</span>
          </div>
        </div>
      </section>
    </aside>
  );
}
