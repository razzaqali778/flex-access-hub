import { Pin, Users } from "lucide-react";
import type { PrioritizedOutcome } from "../types/prioritization.types";

type OutcomeRankCardProps = {
  outcome: PrioritizedOutcome;
};

export function OutcomeRankCard({ outcome }: OutcomeRankCardProps) {
  return (
    <article className="rank-card">
      <div className="fixed-strip">{outcome.fixed ? "FIXED" : "OPEN"}</div>
      <div className="rank-number">{outcome.rank}</div>
      <div className="rank-content">
        <div className="rank-title-row">
          <h2>{outcome.title}</h2>
          <span className="roi-pill">ROI {outcome.roi}x</span>
        </div>
        <div className="meta-row">
          <span>{outcome.functionName}</span>
          <span>{outcome.platform}</span>
          <span className="status-pill">{outcome.status}</span>
          <span className="owner">{outcome.owner}</span>
        </div>
      </div>
      <div className="rank-metrics">
        <span>
          <Users size={15} /> {outcome.demandFte} FTE
        </span>
        <strong>€{Math.round(outcome.fundingEur / 1000)}k</strong>
        <span className="tag-pill">{outcome.governanceTag}</span>
        <Pin size={16} />
      </div>
    </article>
  );
}
