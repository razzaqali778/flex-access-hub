import { filterChanged } from "../state/prioritization.slice";
import type { PrioritizationFilters } from "../types/prioritization.types";
import { useAppDispatch, useAppSelector } from "../../../shared/hooks/redux";

const filterGroups: Array<{
  key: keyof PrioritizationFilters;
  label: string;
  options: string[];
}> = [
  { key: "division", label: "Division", options: ["Consumer Health", "Pharma", "Crop Science", "Enabling Functions"] },
  { key: "level", label: "Level", options: ["All levels", "Strategic", "Execution"] },
  { key: "functionName", label: "Function", options: ["All functions", "Finance", "Marketing & Sales", "Product Supply", "Quality & Regulatory"] },
  { key: "platform", label: "DSO Platform", options: ["All platforms", "CH Consumer & Customer Experience", "CH Data Assets, Analytics & Insights", "CH Product Experience"] },
  { key: "status", label: "Status", options: ["All statuses", "Active", "Planned"] },
  { key: "governance", label: "Governance", options: ["All tags", "L20", "Compliance", "Non-negotiable"] },
];

export function FilterBar() {
  const filters = useAppSelector((state) => state.prioritization);
  const dispatch = useAppDispatch();

  return (
    <section className="filter-panel">
      {filterGroups.map((group) => (
        <div className="filter-row" key={group.key}>
          <span className="filter-label">{group.label}</span>
          <div className="chip-list">
            {group.options.map((option) => (
              <button
                className={filters[group.key] === option ? "chip chip-active" : "chip"}
                key={option}
                onClick={() => dispatch(filterChanged({ key: group.key, value: option }))}
                type="button"
              >
                {option}
              </button>
            ))}
          </div>
        </div>
      ))}
    </section>
  );
}
