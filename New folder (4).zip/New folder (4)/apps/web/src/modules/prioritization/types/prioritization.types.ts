export type OutcomeStatus = "Active" | "Planned";

export type PrioritizedOutcome = {
  id: string;
  rank: number;
  title: string;
  functionName: string;
  platform: string;
  owner: string;
  status: OutcomeStatus;
  roi: number;
  governanceTag: string;
  demandFte: number;
  fundingEur: number;
  fixed: boolean;
};

export type PrioritizationFilters = {
  division: string;
  level: string;
  functionName: string;
  platform: string;
  status: string;
  governance: string;
};
