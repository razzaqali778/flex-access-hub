import type { PrioritizedOutcome } from "../types/prioritization.types";

export const prioritizedOutcomes: PrioritizedOutcome[] = [
  {
    id: "outcome-1",
    rank: 1,
    title: "SAP IBP Demand Planning Integration",
    functionName: "Product Supply",
    platform: "CH Product Experience",
    owner: "Markus Weber",
    status: "Active",
    roi: 3.8,
    governanceTag: "L20",
    demandFte: 4,
    fundingEur: 228000,
    fixed: true,
  },
  {
    id: "outcome-2",
    rank: 2,
    title: "Symptom Checker AI",
    functionName: "Quality & Regulatory",
    platform: "CH Data Assets, Analytics & Insights",
    owner: "Priya Sharma",
    status: "Active",
    roi: 6.2,
    governanceTag: "Compliance",
    demandFte: 4,
    fundingEur: 225000,
    fixed: true,
  },
  {
    id: "outcome-3",
    rank: 3,
    title: "Consumer Health Personalization Engine",
    functionName: "Marketing & Sales",
    platform: "CH Consumer & Customer Experience",
    owner: "Elena Garcia",
    status: "Planned",
    roi: 4.4,
    governanceTag: "Non-negotiable",
    demandFte: 3,
    fundingEur: 170000,
    fixed: false,
  },
];

export function getPrioritizedOutcomes() {
  return prioritizedOutcomes;
}
