import { LockKeyhole } from "lucide-react";
import { getPrioritizedOutcomes } from "../api/prioritization.api";
import { FilterBar } from "../components/filter-bar";
import { OutcomeRankCard } from "../components/outcome-rank-card";
import { ResourceSimulation } from "../components/resource-simulation";

export function PrioritizationPage() {
  const outcomes = getPrioritizedOutcomes();

  return (
    <section className="page">
      <header className="page-header">
        <div>
          <h1>Division Prioritization</h1>
          <p>Consumer Health · Rank outcomes · Check staffing forecast · Lock and submit.</p>
        </div>
        <button className="primary-button" type="button">
          <LockKeyhole size={18} /> Lock Consumer Health
        </button>
      </header>
      <div className="optimization-bar">
        <strong>AI Optimization</strong>
        <button type="button">Optimize for ROI</button>
        <span>Governance Log Connected</span>
      </div>
      <div className="workspace">
        <div className="prioritization-main">
          <FilterBar />
          <div className="rank-list">
            {outcomes.map((outcome) => (
              <OutcomeRankCard key={outcome.id} outcome={outcome} />
            ))}
          </div>
        </div>
        <ResourceSimulation />
      </div>
    </section>
  );
}
