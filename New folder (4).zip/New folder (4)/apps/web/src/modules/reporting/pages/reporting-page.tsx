export function ReportingPage() {
  return (
    <section className="page">
      <header className="page-header">
        <div>
          <h1>Reporting</h1>
          <p>Monitoring, steering, history, and read-model dashboards.</p>
        </div>
      </header>
      <div className="empty-panel">
        This module will own reporting projections, history views, and dashboard summaries.
      </div>
    </section>
  );
}
