export type GovernanceTag = {
  id: string;
  label: string;
  category: "Compliance" | "Funding" | "Strategic" | "Risk";
};
