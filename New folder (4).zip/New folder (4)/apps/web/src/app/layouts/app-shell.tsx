import { BarChart3, ClipboardList, History, Link2, ShieldCheck, Trophy, Users, WalletCards } from "lucide-react";
import { NavLink, Outlet } from "react-router-dom";

const navigation = [
  { to: "/outcomes", label: "Outcomes", icon: ClipboardList },
  { to: "/prioritize", label: "Prioritization", icon: Trophy },
  { to: "/resource-simulation", label: "Resource Simulation", icon: WalletCards },
  { to: "/governance", label: "Governance", icon: ShieldCheck },
  { to: "/users", label: "Users & Roles", icon: Users },
  { to: "/reporting", label: "Reporting", icon: BarChart3 },
  { to: "/history", label: "History", icon: History },
  { to: "/coverage", label: "Outcome Coverage", icon: Link2 },
];

export function AppShell() {
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <span>BAYER AG</span>
          <strong>Resource Allocation</strong>
        </div>
        <nav className="nav-list">
          {navigation.map((item) => (
            <NavLink key={item.to} to={item.to} className="nav-link">
              <item.icon size={18} />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="signed-in">
          <span>Signed in as</span>
          <strong>Bayer Portfolio Lead</strong>
        </div>
      </aside>
      <main className="main-panel">
        <Outlet />
      </main>
    </div>
  );
}
