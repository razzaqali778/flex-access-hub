import { Navigate, Route, Routes } from "react-router-dom";
import { AppShell } from "../layouts/app-shell";
import { GovernancePage } from "../../modules/governance/pages/governance-page";
import { OutcomesPage } from "../../modules/outcomes/pages/outcomes-page";
import { PrioritizationPage } from "../../modules/prioritization/pages/prioritization-page";
import { ReportingPage } from "../../modules/reporting/pages/reporting-page";
import { ResourceSimulationPage } from "../../modules/resource-simulation/pages/resource-simulation-page";
import { UsersPage } from "../../modules/users/pages/users-page";

export function AppRouter() {
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route path="/" element={<Navigate to="/prioritize" replace />} />
        <Route path="/outcomes" element={<OutcomesPage />} />
        <Route path="/prioritize" element={<PrioritizationPage />} />
        <Route path="/resource-simulation" element={<ResourceSimulationPage />} />
        <Route path="/governance" element={<GovernancePage />} />
        <Route path="/users" element={<UsersPage />} />
        <Route path="/reporting" element={<ReportingPage />} />
      </Route>
    </Routes>
  );
}
