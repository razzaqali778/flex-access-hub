import { configureStore } from "@reduxjs/toolkit";
import { prioritizationReducer } from "../../modules/prioritization/state/prioritization.slice";

export const store = configureStore({
  reducer: {
    prioritization: prioritizationReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
