# Resource Allocation Platform

Modulith-first monorepo for the Bayer-style resource allocation prototype.

The platform is planned with:

- React + Redux Toolkit frontend
- NestJS backend modulith
- PostgreSQL persistence through Prisma
- RabbitMQ event-driven communication through a dedicated messaging library
- GitHub Actions for CI and migration validation

## Repository Layout

```text
apps/
  web/                  React application
  api/                  NestJS API modulith

packages/
  contracts/            shared API and event contracts
  database/             Prisma schema, DB client, migrations
  messaging/            RabbitMQ publisher/consumer library
  shared-kernel/        shared domain primitives
  ui/                   reusable React UI primitives
  config/               shared TypeScript config

docs/
  hld/                  high-level design documents
  lld/                  low-level design documents
```

## Product Modules

Initial modules are based on the prototype screens:

- `outcomes`: portfolio outcomes and lifecycle
- `prioritization`: rank outcomes and lock division plans
- `resource-simulation`: capacity, funding, FTE, and staffing forecast
- `governance`: audit trail and governance tags
- `users`: user profile and role ownership
- `reporting`: monitoring, steering, and history

## Current Scaffold Status

- Frontend modules exist for all planned product areas.
- Backend NestJS modules exist for all planned product areas.
- `outcomes` has the first real vertical slice with domain, repository, controller, and event publisher wiring.
- Other modules currently contain placeholders and starting domain types so the team can add use cases without changing structure.

## Local Development

```bash
npm install
npm run dev
```

Start local dependencies:

```bash
docker compose up -d postgres rabbitmq
```

Run individual apps:

```bash
npm run dev:web
npm run dev:api
```

## Documentation

- [Architecture Overview](./docs/architecture.md)
- [HLD Overview](./docs/hld/overview.md)
- [HLD Modules](./docs/hld/modules.md)
- [LLD Frontend](./docs/lld/frontend.md)
- [LLD Backend](./docs/lld/backend.md)
- [LLD Messaging](./docs/lld/messaging.md)
- [LLD Database](./docs/lld/database.md)
- [Implementation Plan](./docs/implementation-plan.md)
- [Monorepo Structure](./docs/monorepo-structure.md)

## Architecture Rule

The backend is a modulith, not microservices on day one.

Business modules must keep strict boundaries, own their persistence access, and communicate through application contracts or events. RabbitMQ details stay inside `packages/messaging`.
